package com.example.todo_caled;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoCaledApplicationTests {

	@Test
	void contextLoads() {
	}

}
