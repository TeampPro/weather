package com.example.todo_caled;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {
		"com.todo.todolist",   // ✅ todo 관련 코드
		"com.todo.holiday"     // ✅ holiday 관련 코드
})
@EnableJpaRepositories(basePackages = {
		"com.todo.todolist.repository",
		"com.todo.holiday.repository"
})
@EntityScan(basePackages = {
		"com.todo.todolist.entity",
		"com.todo.holiday.entity"
})
public class TodoCaledApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoCaledApplication.class, args);
	}

}
