package com.example.todo_caled.weather.dto;

import lombok.Data;

@Data
public class WeatherResponse {
    private String category;
    private String obsValue;

}
